const templateSubscribe = (object) => {
  return `
    Bạn đã đăng ký newsletter của Draco Store thành công 😊.
  `;
};
module.exports = templateSubscribe;


